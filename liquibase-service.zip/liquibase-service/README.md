**Run the application in local with specific profile**
mvn -Dspring.profiles.active=dev spring-boot:run

**Run the application in local with specific profile and liquibase.context**
mvn -Dliquibase.context=xmlgateway -Dspring.profiles.active=dev spring-boot:run


**Run the application with specific profile using executable jar**
mvn clean package spring-boot:repackage
java -jar -Dspring.profiles.active=dev target/spring-boot-liquibase-xml-0.0.1-SNAPSHOT.jar

**Run the application with specific profile and liquibase.contex using executable jar**
mvn clean package spring-boot:repackage
java -jar -Dliquibase.context=xmlgateway -Dspring.profiles.active=dev target/spring-boot-liquibase-xml-0.0.1-SNAPSHOT.jar
java -jar -Dliquibase.context=claimspayment -Dspring.profiles.active=dev target/spring-boot-liquibase-xml-0.0.1-SNAPSHOT.jar

**Run the liquibase using its library**
liquibase --changelog-file=db1/db.changelog-master.xml --url=jdbc:mysql://localhost:3306/first?serverTimezone=UTC --username=avalon --password=1qaz2wsx update

**Swagger**
http://localhost:8081/liquibase/swagger-ui/index.html
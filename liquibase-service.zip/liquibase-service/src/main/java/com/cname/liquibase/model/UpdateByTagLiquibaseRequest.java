package com.cname.liquibase.model;


import lombok.Data;

import javax.validation.constraints.NotEmpty;

@Data
public class UpdateByTagLiquibaseRequest extends LiquibaseRequest{

    @NotEmpty(message = "The tag is a required field.")
    private String tag;
    private int changesToApply;
}

package com.cname.liquibase.model;


import lombok.Data;

import javax.validation.constraints.NotEmpty;

@Data
public class UpdateByChangesToApplyLiquibaseRequest extends LiquibaseRequest{

    @NotEmpty(message = "The changesToApply is a required field.")
    private int changesToApply;
}

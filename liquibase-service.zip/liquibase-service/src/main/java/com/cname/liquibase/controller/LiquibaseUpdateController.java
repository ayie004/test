package com.cname.liquibase.controller;

import com.cname.liquibase.model.LiquibaseResponse;
import com.cname.liquibase.model.UpdateLiquibaseRequest;
import liquibase.Liquibase;
import liquibase.database.Database;
import liquibase.resource.ClassLoaderResourceAccessor;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ResponseStatusException;

import javax.sql.DataSource;
import javax.validation.Valid;
import java.io.StringWriter;
import java.sql.Connection;

import static com.cname.liquibase.util.DatabaseUtil.close;
import static com.cname.liquibase.util.DatabaseUtil.getDatabase;
import static org.apache.commons.lang3.StringUtils.trimToEmpty;

@RestController
public class LiquibaseUpdateController {

    private static final Logger LOGGER = LoggerFactory.getLogger(LiquibaseUpdateController.class);

    @Autowired
    @Qualifier("firstDbDataSource")
    private DataSource firstDbDataSource;

    @PostMapping("/update")
    public String update(@Valid @RequestBody UpdateLiquibaseRequest updateLiquibaseRequest) throws ResponseStatusException {
        return update(updateLiquibaseRequest, false);
    }

    @PostMapping("/preview/update")
    public String previewUpdate(@Valid @RequestBody UpdateLiquibaseRequest updateLiquibaseRequest) throws ResponseStatusException{
        return update(updateLiquibaseRequest, true);
    }

    public String update(UpdateLiquibaseRequest request, boolean isPreview) throws ResponseStatusException{
        Connection connection = null;
        LiquibaseResponse response = new LiquibaseResponse();
        try {
            String changeLogFile = request.getChangeLogFile();

            connection = firstDbDataSource.getConnection();
            Database database = getDatabase(connection);
            Liquibase liquibase = new Liquibase(changeLogFile, new ClassLoaderResourceAccessor(), database);

            // Retrieve the rollback log
            StringWriter stringWriter = new StringWriter();
            String contexts = trimToEmpty(request.getContexts());

            liquibase.update(contexts, stringWriter);
            if (!isPreview) {
                liquibase.update(contexts);
            }
            response.setScript(stringWriter.toString());
            response.setStatus("SUCCESS");
            return stringWriter.toString();
        }catch (Exception ex){
            LOGGER.error("Exception occurred while liquibase update - {} \n{}", ex.getMessage(), ExceptionUtils.getStackTrace(ex));
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, ExceptionUtils.getMessage(ex), ex);
        }
        finally {
            close(connection);
        }
    }


}

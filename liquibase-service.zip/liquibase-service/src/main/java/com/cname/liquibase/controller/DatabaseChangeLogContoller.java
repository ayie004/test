package com.cname.liquibase.controller;

import com.cname.liquibase.dao.DatabaseChangeLogDAO;
import com.cname.liquibase.form.DatabaseChangeLogForm;
import com.cname.liquibase.model.DatabaseChangeLog;
import com.cname.liquibase.util.DatabaseUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

import javax.sql.DataSource;
import java.sql.Connection;
import java.util.ArrayList;
import java.util.List;

import static com.cname.liquibase.util.DatabaseUtil.close;

@Controller
public class DatabaseChangeLogContoller {

    private static final Logger LOGGER = LoggerFactory.getLogger(DatabaseChangeLogContoller.class);

    @Autowired
    private DataSource firstDbDataSource;
    @Autowired
    private DatabaseChangeLogDAO databaseChangeLogDAO;

    @PostMapping("/")
    public String filter( DatabaseChangeLogForm databaseChangeLogForm, Model model) {
        LOGGER.info("DatabaseChangeLogContoller.filter() ********************* Start");
        try {
            String dayExecuted = databaseChangeLogForm.getDayExecuted();
            LOGGER.debug("dayExecuted = "+dayExecuted);

            List<DatabaseChangeLog> databaseChangeLogs;
            List<String> dayExecutionList;

            Connection connection = firstDbDataSource.getConnection();
            try {
                dayExecutionList = databaseChangeLogDAO.getExecutedDays(connection);
                databaseChangeLogs = databaseChangeLogDAO.getDatabaseChangeLogs(connection, dayExecuted);
            }finally {
                close(connection);
            }

            model.addAttribute("dayExecutionList",dayExecutionList);
            model.addAttribute("databaseChangeLogs",databaseChangeLogs);
            model.addAttribute("databaseChangeLogForm", databaseChangeLogForm);
        }catch (Exception ex){
            LOGGER.error(""+ex.getMessage(), ex);
        }
        LOGGER.info("DatabaseChangeLogContoller.filter() ********************* End");
        return "index";
    }

    @GetMapping("/")
    public String index(Model model) {
        LOGGER.info("DatabaseChangeLogContoller.index() ********************* Start");
        Connection connection = null;
        try {
            DatabaseChangeLogForm databaseChangeLogForm = new DatabaseChangeLogForm();
            List<DatabaseChangeLog> databaseChangeLogs = new ArrayList<>();
            List<String> dayExecutionList;

            connection = firstDbDataSource.getConnection();
            dayExecutionList = databaseChangeLogDAO.getExecutedDays(connection);

            if (!CollectionUtils.isEmpty(dayExecutionList)) {
                String dayExecuted = dayExecutionList.get(0);
                LOGGER.debug("dayExecuted = "+dayExecuted);
                databaseChangeLogForm.setDayExecuted(dayExecuted);

                databaseChangeLogs = databaseChangeLogDAO.getDatabaseChangeLogs(connection, dayExecuted);
            }

            model.addAttribute("dayExecutionList",dayExecutionList);
            model.addAttribute("databaseChangeLogs",databaseChangeLogs);
            model.addAttribute("databaseChangeLogForm", databaseChangeLogForm);

        }catch (Exception ex){
            LOGGER.error(""+ex.getMessage(), ex);
        } finally {
            close(connection);
        }
        LOGGER.info("DatabaseChangeLogContoller.index() ********************* End");
        return "index";
    }


}

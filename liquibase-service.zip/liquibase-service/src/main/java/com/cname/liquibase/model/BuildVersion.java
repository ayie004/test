package com.cname.liquibase.model;

import lombok.Data;

@Data
public class BuildVersion {

    private String version;

}

package com.cname.liquibase.model;

import lombok.Data;

@Data
public class RollbackLiquibaseRequest extends LiquibaseRequest {

    private String tag;
    private String date;
    private int changesToApply;
}

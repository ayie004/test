package com.cname.liquibase.controller;

import com.cname.liquibase.dao.DatabaseChangeLogDAO;
import com.cname.liquibase.model.RollbackLiquibaseRequest;
import com.cname.liquibase.util.DatabaseUtil;
import liquibase.Liquibase;
import liquibase.database.Database;
import liquibase.database.DatabaseFactory;
import liquibase.database.jvm.JdbcConnection;
import liquibase.resource.ClassLoaderResourceAccessor;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import javax.sql.DataSource;
import java.io.StringWriter;
import java.sql.Connection;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Date;

import static com.cname.liquibase.util.DatabaseUtil.close;
import static com.cname.liquibase.util.DatabaseUtil.getDatabase;
import static org.apache.commons.lang3.StringUtils.isEmpty;

@RestController
public class LiquibaseRollbackController {

    @Autowired
    private DataSource firstdbDataSource;

    @Autowired
    private DatabaseChangeLogDAO databaseChangeLogDAO;

    @PostMapping("/rollback/tag")
    public String rollbackByTag(@RequestBody RollbackLiquibaseRequest rollback) throws Exception{
        return rollbackByTag(rollback, false);
    }

    @PostMapping("/rollback/preview/tag")
    public String rollbackByTagPreview(@RequestBody RollbackLiquibaseRequest rollback) throws Exception{
        return rollbackByTag(rollback, true);
    }

    @PostMapping("/rollback/date")
    public String rollbackByDate(@RequestBody RollbackLiquibaseRequest rollback) throws Exception{
        return rollbackByDate(rollback, false);
    }

    @PostMapping("/rollback/preview/date")
    public String rollbackByDatePreview(@RequestBody RollbackLiquibaseRequest rollback) throws Exception{
        return rollbackByDate(rollback, true);
    }

    @PostMapping("/rollback/numberofchange")
    public String rollbackByNumberOfChange(@RequestBody RollbackLiquibaseRequest rollback) throws Exception{
        return rollbackByNumberOfChange(rollback, false);
    }

    @PostMapping("/rollback/preview/numberofchange")
    public String rollbackByNumberOfChangePreview(@RequestBody RollbackLiquibaseRequest rollback) throws Exception{
        return rollbackByNumberOfChange(rollback, true);
    }

    public String rollbackByTag(RollbackLiquibaseRequest rollback, boolean isPreview) throws Exception{

        String changeLogFile = rollback.getChangeLogFile();
        String tagToRollbackTo = rollback.getTag();

        if(isEmpty(changeLogFile)){
            return "The changeLogFile is required.";
        }
        if(isEmpty(tagToRollbackTo)){
            return "The tagToRollbackTo is required.";
        }
        Connection connection = null;
        try {
            connection = getConnection();

            Database database = getDatabase(connection);
            Liquibase liquibase = new Liquibase(changeLogFile, new ClassLoaderResourceAccessor(), database);

            // Retrieve the rollback log
            StringWriter stringWriter = new StringWriter();
            liquibase.rollback(tagToRollbackTo, StringUtils.trimToEmpty(rollback.getContexts()), stringWriter);

            if(!isPreview) {
                // Execute rollback
                liquibase.rollback(tagToRollbackTo, StringUtils.trimToEmpty(rollback.getContexts()));

                String rollbackLog = "[RollbackToTag=" + tagToRollbackTo + "] " + stringWriter.toString();
                databaseChangeLogDAO.saveRollbackEvent(getConnection(), changeLogFile, rollbackLog, "RB_BY_TAG");
            }

            return stringWriter.toString();
        }finally {
            close(connection);
        }
    }

    public String rollbackByDate(RollbackLiquibaseRequest rollback, boolean isPreview) throws Exception{

        // D:\workspace\liquibase-service\src\main\resources\liquibase\db1\db.changelog-master.xml

        String changeLogFile = rollback.getChangeLogFile();
        Date dayToRollbackTo = new SimpleDateFormat("mm/dd/yyyy").parse(rollback.getDate());
        //changeLogFile = "liquibase/db1/db.changelog-master.xml";

        if(isEmpty(changeLogFile)){
            return "The changeLogFile is required.";
        }
        if(dayToRollbackTo == null){
            return "The dayToRollbackTo is required with the date format mm/dd/yyyy.";
        }

        Connection connection = null;
        try {
            connection = getConnection();
            Database database = getDatabase(connection);
            Liquibase liquibase = new Liquibase(changeLogFile, new ClassLoaderResourceAccessor(), database);

            // Retrieve the rollback log
            StringWriter stringWriter = new StringWriter();
            liquibase.rollback(dayToRollbackTo, StringUtils.trimToEmpty(rollback.getContexts()), stringWriter);

            if (!isPreview) {
                // Execute rollback
                liquibase.rollback(dayToRollbackTo, StringUtils.trimToEmpty(rollback.getContexts()));

                String rollbackLog = "[RollbackToDate=" + dayToRollbackTo + "] " + stringWriter.toString();
                databaseChangeLogDAO.saveRollbackEvent(getConnection(), changeLogFile, rollbackLog, "RB_BY_DATE");
            }

            return stringWriter.toString();
        }finally {
            close(connection);
        }
    }

    public String rollbackByNumberOfChange(RollbackLiquibaseRequest rollback, boolean isPreview) throws Exception{

        // D:\workspace\liquibase-service\src\main\resources\liquibase\db1\db.changelog-master.xml

        String changeLogFile = rollback.getChangeLogFile();
        int changesToRollbackTo = rollback.getChangesToApply();
        //changeLogFile = "liquibase/db1/db.changelog-master.xml";

        if(isEmpty(changeLogFile)){
            return "The changeLogFile is required.";
        }
        if(changesToRollbackTo <= 0){
            return "The changesToRollbackTo is invalid";
        }
        if(changesToRollbackTo > 10){
            return "The changesToRollbackTo provided must not be greater than 10";
        }

        Connection connection = null;
        try {
            connection = getConnection();
            Database database = getDatabase(connection);
            Liquibase liquibase = new Liquibase(changeLogFile, new ClassLoaderResourceAccessor(), database);

            // Retrieve the rollback log
            StringWriter stringWriter = new StringWriter();
            liquibase.rollback(changesToRollbackTo, StringUtils.trimToEmpty(rollback.getContexts()), stringWriter);

            if(!isPreview) {
                // Execute rollback
                liquibase.rollback(changesToRollbackTo, StringUtils.trimToEmpty(rollback.getContexts()));

                String rollbackLog = "[RollbackToNumberOfChanges=" + changesToRollbackTo + "] " + stringWriter.toString();
                databaseChangeLogDAO.saveRollbackEvent(getConnection(), changeLogFile, rollbackLog, "RB_BY_NOOFCHANGE");
            }

            return stringWriter.toString();
        }finally {
            close(connection);
        }
    }

    private Connection getConnection() throws SQLException {
        return firstdbDataSource.getConnection();
    }
}

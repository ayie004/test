package com.cname.liquibase.model;

import lombok.Data;

import javax.validation.constraints.NotEmpty;

@Data
public class LiquibaseRequest {

    @NotEmpty(message = "The changeLogFile is a required field.")
    private String changeLogFile;
    private String contexts;


}

package com.cname.liquibase.dao;

import com.cname.liquibase.model.DatabaseChangeLog;
import com.cname.liquibase.util.DateUtil;
import org.springframework.stereotype.Component;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

@Component
public class DatabaseChangeLogDAO {

    public List<String> getExecutedDays(Connection connection) throws SQLException {
        List<String> dayExecutionList = new ArrayList<>();

        PreparedStatement stmt = null;
        ResultSet rs = null;
        try {
            stmt = connection.prepareStatement("select distinct DATE_FORMAT(DATEEXECUTED, '%Y/%m/%d') AS DAYEXECUTED from databasechangelog");
            rs=stmt.executeQuery();
            while(rs.next()){
                dayExecutionList.add(rs.getString(1));
            }
        }finally {
            if(rs != null) rs.close();
            if(stmt != null) stmt.close();
        }
        return dayExecutionList;
    }

    public List<DatabaseChangeLog> getDatabaseChangeLogs(Connection connection, String dayExecuted) throws SQLException {
        List<DatabaseChangeLog> databaseChangeLogs = new ArrayList<>();
        PreparedStatement stmt = null;
        ResultSet rs = null;
        try {
            stmt = connection.prepareStatement("SELECT \t`ID`, \n" +
                    "\t`AUTHOR`, \n" +
                    "\t`FILENAME`, \n" +
                    "\t`DATEEXECUTED`, \n" +
                    "\t`ORDEREXECUTED`, \n" +
                    "\t`EXECTYPE`, \n" +
                    "\t`MD5SUM`, \n" +
                    "\t`DESCRIPTION`, \n" +
                    "\t`COMMENTS`, \n" +
                    "\t`TAG`, \n" +
                    "\t`LIQUIBASE`, \n" +
                    "\t`CONTEXTS`, \n" +
                    "\t`LABELS`, \n" +
                    "\t`DEPLOYMENT_ID`\n" +
                    "\tFROM \n" +
                    "\t`first`.`databasechangelog` \n" +
                    "\t WHERE DATE_FORMAT(DATEEXECUTED, '%Y/%m/%d') = ? LIMIT 0, 1000;");
            stmt.setString(1, dayExecuted);
            rs = stmt.executeQuery();
            while (rs.next()) {
                DatabaseChangeLog databaseChangeLog = new DatabaseChangeLog();
                databaseChangeLog.setId(rs.getString("ID"));
                databaseChangeLog.setAuthor(rs.getString("AUTHOR"));
                databaseChangeLog.setFilename(rs.getString("FILENAME"));
                databaseChangeLog.setDateExecuted(DateUtil.toDate(rs.getDate("DATEEXECUTED")));
                databaseChangeLog.setOrderExecuted(rs.getString("ORDEREXECUTED"));
                databaseChangeLog.setExecType(rs.getString("EXECTYPE"));
                databaseChangeLog.setMd5Sum(rs.getString("MD5SUM"));
                databaseChangeLog.setDescription(rs.getString("DESCRIPTION"));
                databaseChangeLog.setComments(rs.getString("COMMENTS"));
                databaseChangeLog.setTag(rs.getString("TAG"));
                databaseChangeLog.setLiquibaseVersion(rs.getString("LIQUIBASE"));
                databaseChangeLog.setContexts(rs.getString("CONTEXTS"));
                databaseChangeLog.setLabels(rs.getString("LABELS"));
                databaseChangeLog.setDeploymentId(rs.getString("DEPLOYMENT_ID"));
                databaseChangeLogs.add(databaseChangeLog);
            }
        }finally {
            if(rs != null) rs.close();
            if(stmt != null) stmt.close();
        }
        return databaseChangeLogs;
    }

    public void saveRollbackEvent(Connection conn, String changeLogFile, String rollbackLog, String operation) throws SQLException {
        PreparedStatement ps = null;
        try {
            ps = conn.prepareStatement("insert into databasechangelog_audit (db_change_log,operation,rollback_log,created_date) values (?,?,?,now())");
            ps.setString(1, changeLogFile);
            ps.setString(2, operation);
            ps.setString(3, rollbackLog);
            ps.execute();
        }finally {
            if(ps!=null)ps.close();
            if(conn!=null)conn.close();
        }
    }
}

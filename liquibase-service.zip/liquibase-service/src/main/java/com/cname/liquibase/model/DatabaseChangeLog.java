package com.cname.liquibase.model;

import lombok.Data;

import java.util.Date;
@Data
public class DatabaseChangeLog {

    private String id;
    private String author;
    private String filename;
    private Date dateExecuted;
    private String orderExecuted;
    private String execType;
    private String md5Sum;
    private String description;
    private String comments;
    private String tag;
    private String liquibaseVersion;
    private String contexts;
    private String labels;
    private String deploymentId;

}


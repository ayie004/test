package com.cname.liquibase.form;

public class DatabaseChangeLogForm {

    private String dayExecuted;


    public String getDayExecuted() {
        return dayExecuted;
    }

    public void setDayExecuted(String dayExecuted) {
        this.dayExecuted = dayExecuted;
    }
}

package com.cname.liquibase.util;

import java.util.Date;

public class DateUtil {

    public static Date toDate(java.sql.Date sqlDate){
        if(sqlDate == null){
            return null;
        }
        return new Date(sqlDate.getTime());
    }
}

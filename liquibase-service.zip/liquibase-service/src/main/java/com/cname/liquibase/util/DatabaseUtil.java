package com.cname.liquibase.util;

import com.cname.liquibase.controller.LiquibaseUpdateController;
import liquibase.database.Database;
import liquibase.database.DatabaseFactory;
import liquibase.database.jvm.JdbcConnection;
import liquibase.exception.DatabaseException;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.web.server.ResponseStatusException;

import java.sql.Connection;

public class DatabaseUtil {

    private static final Logger LOGGER = LoggerFactory.getLogger(LiquibaseUpdateController.class);

    public static Database getDatabase( Connection connection ) throws DatabaseException {
        return DatabaseFactory.getInstance().findCorrectDatabaseImplementation(new JdbcConnection(connection));
    }

    public static void close(Connection connection) throws ResponseStatusException {
        if(connection == null){
            return;
        }
        try {
            connection.close();
        }catch (Exception ex){
            LOGGER.error("Exception occurred while closing the connection - {} \n{}", ex.getMessage(), ExceptionUtils.getStackTrace(ex));
            throw new ResponseStatusException(HttpStatus.FAILED_DEPENDENCY, ExceptionUtils.getMessage(ex), ex);
        }
    }


}

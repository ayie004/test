package com.cname.liquibase.config;

import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Info;
import liquibase.integration.spring.SpringLiquibase;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.liquibase.LiquibaseProperties;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.jdbc.DataSourceBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Primary;

import javax.sql.DataSource;

import static org.apache.commons.lang3.StringUtils.isNotEmpty;

public class BaseApplicationConfig {

    @Value("${liquibase.context:}")
    private String liquibaseContext;

    @Value("${spring.datasource.firstdb.url}")
    private String springDatasourceFirstDbUrl;
    @Value("${spring.datasource.firstdb.username}")
    private String springDatasourceFirstDbUsername;
    @Value("${spring.datasource.firstdb.password}")
    private String springDatasourceFirstDbPassword;
    @Value("${spring.datasource.firstdb.driverclassname}")
    private String springDatasourceFirstDbDriverClassName;

    @Value("${spring.datasource.seconddb.url}")
    private String springDatasourceSecondDbUrl;
    @Value("${spring.datasource.seconddb.username}")
    private String springDatasourceSecondDbUsername;
    @Value("${spring.datasource.seconddb.password}")
    private String springDatasourceSecondDbPassword;
    @Value("${spring.datasource.seconddb.driverclassname}")
    private String springDatasourceSecondDbDriverClassName;

    @Primary
    @Bean()
    @Qualifier("firstDbDataSource")
    public DataSource firstDbDataSource() {
        return DataSourceBuilder.create()
                .url(springDatasourceFirstDbUrl)
                .driverClassName(springDatasourceFirstDbDriverClassName)
                .username(springDatasourceFirstDbUsername)
                .password(springDatasourceFirstDbPassword)
                .build();
    }

    @Bean
    @ConfigurationProperties(prefix = "liquibase.firstdb")
    public LiquibaseProperties firstDbLiquibaseProperties() {
        return new LiquibaseProperties();
    }

    @Bean()
    public SpringLiquibase firstDbLiquibase() {
        return springLiquibase(firstDbDataSource(), firstDbLiquibaseProperties());
    }

    @Bean()
    @Qualifier("secondaryDataSource")
    //@ConfigurationProperties(prefix = "spring.datasource.seconddb")
    public DataSource secondaryDataSource() {
        return DataSourceBuilder.create()
                .url(springDatasourceSecondDbUrl)
                .driverClassName(springDatasourceSecondDbDriverClassName)
                .username(springDatasourceSecondDbUsername)
                .password(springDatasourceSecondDbPassword)
                .build();
    }

    @Bean
    @ConfigurationProperties(prefix = "liquibase.seconddb")
    public LiquibaseProperties secondaryLiquibaseProperties() {
        return new LiquibaseProperties();
    }

    @Bean()
    public SpringLiquibase secondDbLiquibase() {
        return springLiquibase(secondaryDataSource(), secondaryLiquibaseProperties());
    }

    private SpringLiquibase springLiquibase(DataSource dataSource, LiquibaseProperties properties) {

        SpringLiquibase liquibase = new SpringLiquibase();
        liquibase.setDataSource(dataSource);
        liquibase.setChangeLog(properties.getChangeLog());
        //liquibase.setContexts(properties.getContexts());
        if(isNotEmpty(liquibaseContext)){
            liquibase.setContexts(liquibaseContext);
        }
        liquibase.setShouldRun(properties.isEnabled());
        liquibase.setDefaultSchema(properties.getDefaultSchema());
        liquibase.setDropFirst(properties.isDropFirst());
        liquibase.setShouldRun(properties.isEnabled());
        liquibase.setLabels(properties.getLabels());
        liquibase.setChangeLogParameters(properties.getParameters());
        liquibase.setRollbackFile(properties.getRollbackFile());

        return liquibase;
    }

    @Bean
    public OpenAPI openAPI() {
        return new OpenAPI().info(new Info().title("Liquibase example")
                .description("Liquibase application")
                .version("v0.0.1"));
    }

}

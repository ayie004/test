package com.cname.liquibase.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Data
public class LiquibaseResponse {

    public String status;

    public String script;

    public String errorMessage;

    public String stackTrace;

}

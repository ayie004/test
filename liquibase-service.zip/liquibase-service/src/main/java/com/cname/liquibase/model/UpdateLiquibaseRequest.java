package com.cname.liquibase.model;


import lombok.Data;

@Data
public class UpdateLiquibaseRequest extends LiquibaseRequest{

}

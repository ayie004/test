--liquibase formatted sql

--preconditions onFail:MARK_RAN
--precondition-sql-check expectedResult:0 SELECT COUNT(*) FROM information_schema.tables WHERE table_schema = 'first' AND TABLE_NAME = 'address'

--changeset amendoza:1 context:vss-api
--comment: Create address table
CREATE TABLE `address` (
            `id` int(11) NOT NULL Auto_increment,
            `user_id` int(11) DEFAULT NULL,
            `street` varchar(100) NOT NULL,
            `city` varchar(100) DEFAULT NULL,
            `pin` int(4) DEFAULT NULL,
            `zipcode` varchar(5) DEFAULT NULL,
            PRIMARY KEY (`id`)
            ) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--rollback drop table address;
--liquibase formatted sql

--preconditions onFail:MARK_RAN
--precondition-sql-check expectedResult:0 SELECT COUNT(*) FROM information_schema.columns WHERE table_schema = 'first' AND COLUMN_NAME = 'phone_number'

--changeset amendoza:1 context:vss-api
--comment: Rename phone to phone_number in user table
ALTER TABLE first.user RENAME COLUMN phone TO phone_number;

--rollback ALTER TABLE first.user RENAME COLUMN phone_number TO phone;
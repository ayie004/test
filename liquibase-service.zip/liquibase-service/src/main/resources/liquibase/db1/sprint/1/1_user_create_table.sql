--liquibase formatted sql

--preconditions onFail:MARK_RAN
--precondition-sql-check expectedResult:0 SELECT COUNT(*) FROM information_schema.tables WHERE table_schema = 'first' AND TABLE_NAME = 'user'

--changeset amendoza:1 context:vss-api
--comment: Create user table
CREATE TABLE `user` (
            `id` int(11) NOT NULL Auto_increment,
            `name` varchar(50) NOT NULL,
            `email` varchar(100) DEFAULT NULL,
            `phone` varchar(15) DEFAULT NULL,
            `address` int(11) NOT NULL,
            PRIMARY KEY (`id`)
            ) ENGINE=InnoDB DEFAULT CHARSET=latin1

--rollback drop table user;
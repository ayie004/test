--liquibase formatted sql

--changeset amendoza:1 context:vss-api
--comment: Insert record in address table
INSERT INTO `first`.`address`
            ( `user_id`, `street`, `city`, `pin`, `zipcode`)
            VALUES (1, '1 Park Ave', 'Metropolis',1,'13245');